export default {
    salt: 10,
}