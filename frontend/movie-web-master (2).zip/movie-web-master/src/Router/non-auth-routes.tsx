import { lazy } from 'react';

// Importing routes
// const Login = lazy(() => import('../Pages/Login_Page'));
// const SignUp = lazy(() => import('../Pages/SignUpPage'));


export default [
//   {
//     name: 'Login',
//     path: '/',
//     component: <Login />
//   },
//   {
//     name: 'SignUp',
//     path: '/signup',
//     component: <SignUp />
//   },
];


